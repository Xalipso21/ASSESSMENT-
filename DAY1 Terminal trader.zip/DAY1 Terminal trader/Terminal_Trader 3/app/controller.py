from app.account import Account
import views
from app.util import get_price
import time



def run():
    welcome_menu()

def welcome_menu():
    while True:
        selection = views.welcome_screen()
        if selection not in ["1", "2", "3"]:
            views.improper_selection()
            continue

        if selection == "1":
            username = views.get_username()
            balance = views.add_balance()
            password = views.get_password()
            confirm_pasword = views.confirm_password()

            if password != confirm_pasword:
                views.improper_password()
                continue
            if not balance.isdigit() or int(balance) < 0:
                views.improper_balance()

            account = Account(username=username, balance=balance)
            account.set_password(password)
            account.save()
            logged_in_homepage(account)
            return

        elif selection == "2":
            username = views.get_username()
            password = views.get_password()
            logged_in_account = Account.login(username=username, password=password)
            if logged_in_account:
                logged_in_homepage(logged_in_account)
                return
            else:
                print("Invalid credentials")
                continue

        elif selection == "3":
            view.goodbye()
            return

def logged_in_homepage(account):

    while True:
        selection = views.logged_in_screen(account.username, account.balance)
        
        if selection not in ["1", "2", "3", "4", "5", "6", "7", "8"]:
            views.improper_selection()
            time.sleep(3)

        if selection == '1':
            views.account_positions(account.username)
            positions = account.get_positions()
            views.show_positions(positions)

        elif selection == "2":
             views.get_money()
             balance=account.add_balance()
             account.save()

        elif selection == "3":
             ticker= views.get_ticker()
             views.current_price(ticker,get_price(ticker))

        elif selection == "4":
            ticker= views.get_ticker()
            amount= views.get_amount()
            buys=account.buy(ticker,amount)
            if buys==ValueError:
                views.balance_error()
            elif buys==KeyError:
                views.stock_error()
            else:
                views.trade_succes("bought",amount,ticker)

        

        elif selection == "5":
            ticker= views.get_ticker()
            amount= views.get_amount()
            sells=account.sell(ticker,amount)
            if sells==KeyError:
                views.bad_price()
            elif sells==ValueError:
                views.sell_error()
            else:
                views.trade_succes("sold",amount,ticker)

        

        elif selection == "6":
            views.account_trades(account.username)
            trades = account.get_trades()
            ticker=views.get_ticker()
            views.show_trades(ticker)
        

        elif selection == "7":
            views.welcome_menu()
        

        elif selection == "8":
            views.goodbye()

"""
Main Menu:
    1. see balance & positions
    2. deposit money
    3. look up stock price
    4. buy stock
    5. sell stock
    6. trade history
    7. logout
    8. exit
"""