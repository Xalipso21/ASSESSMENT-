from app.orm import ORM
from app.util import get_price


class Position(ORM):

    table = ''
    fields = []

    def __init__(self, **kwargs):
        self.pk = kwargs.get('pk')
        self.accounts_pk = kwargs.get('accounts_pk')
        self.ticker = kwargs.get('ticker')
        self.shares = kwargs.get('shares')

    def current_value(self):
        price = get_price(self.ticker)
        value = price * self.shares
        return value
