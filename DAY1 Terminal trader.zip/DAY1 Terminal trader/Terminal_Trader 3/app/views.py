def welcome_menu():
    print()
    print("Trading Platform")
    print()
    print("1 Create Account")
    print("2 Log In")
    print("3 Quit")

def improper_selection():
    print("Selction incorrect. Please try again")

def goodbye():
    print("Goodbye!")
    quit()

def welcome_screen():
    print()
    print("Please Pick an Option: ",end="")
    return input()

def get_username():
    return input("Please enter username: ")

def get_password():
    return input("Please enter a 10 character max password: ")

def confirm_password():
    return input("Please confirm your passwordd: ")

def improper_password():
    print("Password Incorrect!")

def add_balance():
    return input("Please add balance: ")

def improper_balance():
    print("Incorrect balance input")

def get_ticker():
    return input("Please Input Ticker: ")

def get_amount():
    return input("Please Input Amount: ")

def balance_error():
    print()
    print("Insufficient Funds to complete transaction")

def stock_error():
    print()
    print("Stock does not exist! Try Again")

def trade_succes(side,amount,ticker):
    print("Congrats you {} {} of {} !".format(side,amount,ticker))
    

def current_price(ticker,price):
    print("the Price of the {} is : {}".format(ticker,price))

def sell_error():
    print("Unable to sell")

def goodbye():
    print("Goodbye!")

def bad_price():
    print("Bad price")


    

def logged_in_screen():
    print()
    print("1 View Account and Positions")
    print("2 Deposit money")
    print("3 View Stock Price")
    print("4 Buy Stock")
    print("5 Sell Stock")
    print("6 Trade History")
    print("7 Log Out")
    print("8 Exit Application")

