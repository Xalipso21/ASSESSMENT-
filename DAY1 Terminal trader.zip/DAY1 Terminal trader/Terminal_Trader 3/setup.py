from data.schema import schema
from data.seed import seed

schema()
seed()