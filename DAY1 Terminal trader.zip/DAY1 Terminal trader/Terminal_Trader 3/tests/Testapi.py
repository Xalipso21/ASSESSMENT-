import unittest
from data import schema, seed
from app.account import Account
from app.util import gapi_key
from app.util import hash_password


import os

Account.dbpath = "testapi.db"

class TestAccount(unittest.TestCase):

    def testCreate_user():
        
        password="FGHJGFD"
        passwordhash= hash_password(password)
        test = Account(pk=1, username="Mike Bloom", password_hash=passwordhash,balance=3000)
        api1= account.generate_api_key()
        account.save()
        account.login(username="Mike Bloom",password_hash=passwordhash)
        self.assertEqual(test.api_key, api1, "Api Key is still the same when we reload ")
        


        